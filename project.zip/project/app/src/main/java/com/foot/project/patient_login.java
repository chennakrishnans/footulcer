package com.foot.project;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;

public class patient_login extends AppCompatActivity {

    private EditText editpatient_id, editpassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_login);

        editpatient_id = findViewById(R.id.editTextText8);
        editpassword = findViewById(R.id.editTextTextPassword);
        Button buttonLogin = findViewById(R.id.button11);

        buttonLogin.setOnClickListener(view -> {
            if (isValidInput()) {
                // Call the Patient_homepage method
                patientHomepage();
            } else {
                Toast.makeText(patient_login.this, "Invalid input, please check your details", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void patientHomepage() {
        String url = IPv4Connection.getBaseUrl() +"patient_login.php";

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                this::onResponse,
                error -> {
                    Toast.makeText(patient_login.this, "Network error: " + error, Toast.LENGTH_SHORT).show();
                    Log.e("res", "response" + error);
                }) {
            @Override
            public byte[] getBody() {
                try {
                    JSONObject jsonBody = new JSONObject();
                    jsonBody.put("patient_id", editpatient_id.getText().toString());
                    jsonBody.put("password", editpassword.getText().toString());
                    return jsonBody.toString().getBytes(StandardCharsets.UTF_8);
                } catch (JSONException e) {
                    e.printStackTrace();
                    return null;
                }
            }

            @Override
            public String getBodyContentType() {
                return "application/json";
            }
        };

        Volley.newRequestQueue(this).add(stringRequest);
    }

    private void onResponse(String response) {
        Log.e("Response", "Response: " + response);
        try {
            JSONObject jsonResponse = new JSONObject(response);

            boolean success = jsonResponse.optBoolean("success", true);

            if (success) {
                // Login successful, navigate to another activity
                Intent intent = new Intent(patient_login.this, Patient_homepage.class);
                startActivity(intent);
                // Optional: Finish the LoginActivity to prevent going back
                finish();
            } else {
                String message = jsonResponse.optString("message", "Unknown error");
                Toast.makeText(patient_login.this, message, Toast.LENGTH_SHORT).show();
            }
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(patient_login.this, "JSON parsing error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private boolean isValidInput() {
        // Perform your input validation logic here
        // Return true if input is valid, otherwise return false
        return true;
    }
}
