package com.foot.project;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class add_floatingbutton extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.floatingbutton);

        // Assuming the ImageButton with ID is imageButtonInFloatingButton
        ImageButton overlay_add_patient = findViewById(R.id.overlay_add_patient);

        // Set click listener for the ImageButton
        overlay_add_patient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Create an Intent to navigate to the desired activity (e.g., add_patient)
                Intent intent = new Intent(add_floatingbutton.this, add_patient.class);

                // Start the desired activity
                startActivity(intent);

                // Finish the current activity if needed
                finish();
            }
        });
    }
}
