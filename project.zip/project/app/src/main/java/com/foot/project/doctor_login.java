package com.foot.project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class doctor_login extends AppCompatActivity {
    private EditText editTextTextEmailAddress, editTextTextPassword;
    private String password;
    private final String URL = IPv4Connection.getBaseUrl() + "doctor_login.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_login);

        editTextTextEmailAddress = findViewById(R.id.editTextText);
        editTextTextPassword = findViewById(R.id.editTextText2);

        Button loginButton = findViewById(R.id.button4);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String doctorId = editTextTextEmailAddress.getText().toString().trim();
                password = editTextTextPassword.getText().toString().trim();

                if (doctorId.isEmpty() || password.isEmpty()) {
                    Toast.makeText(doctor_login.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                } else {
                    // Create a request to the PHP script URL
                    StringRequest stringRequest = new StringRequest(Request.Method.POST, URL,
                            new Response.Listener<String>() {
                                @Override
                                public void onResponse(String response) {
                                    try {
                                        JSONObject jsonObject = new JSONObject(response);
                                        String status = jsonObject.getString("status");
                                        String message = jsonObject.getString("message");

                                        if (status.equals("success")) {
                                            Toast.makeText(doctor_login.this, message, Toast.LENGTH_SHORT).show();
                                            Intent intent = new Intent(doctor_login.this, doctor_homepage.class);
                                            startActivity(intent);
                                        } else {
                                            Toast.makeText(doctor_login.this, message, Toast.LENGTH_SHORT).show();
                                        }
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                }
                            },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    if (error instanceof TimeoutError) {
                                        Toast.makeText(doctor_login.this, "Timeout error", Toast.LENGTH_SHORT).show();
                                    } else {
                                        Toast.makeText(doctor_login.this, "Error: " + error.toString(), Toast.LENGTH_SHORT).show();
                                    }
                                }
                            }) {
                        @Override
                        protected Map<String, String> getParams() throws AuthFailureError {
                            Map<String, String> params = new HashMap<>();
                            params.put("doctor_id", doctorId);
                            params.put("password", password);
                            return params;
                        }
                    };

                    // Set retry policy
                    stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                            0,
                            DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                            DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

                    // Add the request to the RequestQueue
                    RequestQueue requestQueue = Volley.newRequestQueue(doctor_login.this);
                    requestQueue.add(stringRequest);
                }
            }
        });
    }
}
