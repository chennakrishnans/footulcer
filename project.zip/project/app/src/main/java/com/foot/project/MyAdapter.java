package com.foot.project;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyAdapterViewHolder> {

    private List<ItemsActivity> itemsList;

    public MyAdapter(List<ItemsActivity> itemsList) {
        this.itemsList = itemsList;
    }

    @NonNull
    @Override
    public MyAdapterViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.items, parent, false);
        return new MyAdapterViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyAdapterViewHolder holder, int position) {
        if (itemsList == null || itemsList.isEmpty()) {
            return;
        }

        ItemsActivity item = itemsList.get(position);
        holder.patientIdTextView.setText(String.valueOf(item.getPatientId()));  // Ensure item.getPatientId() returns a String
        holder.nameTextView.setText(item.getName());
        holder.lastDateTextView.setText(item.getLastDateOfConsultation());

        // Set OnClickListener to open PatientDetailsActivity with the selected patient's details
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), patient_details.class);
                intent.putExtra("patient_id", item.getPatientId());
                intent.putExtra("name", item.getName());
                v.getContext().startActivity(intent);
            }
        });
    }


    @Override
    public int getItemCount() {
        if (itemsList == null) {
            return 0;
        }
        return itemsList.size();
    }

    public void setItems(List<ItemsActivity> itemsList) {
        this.itemsList = itemsList;
        notifyDataSetChanged();  // Notify adapter that the data set has changed
    }

    static class MyAdapterViewHolder extends RecyclerView.ViewHolder {

        private TextView patientIdTextView;
        private TextView nameTextView;
        private TextView lastDateTextView;

        public MyAdapterViewHolder(@NonNull View itemView) {
            super(itemView);
            patientIdTextView = itemView.findViewById(R.id.textView56);
            nameTextView = itemView.findViewById(R.id.textView57);
            lastDateTextView = itemView.findViewById(R.id.textView58);
        }
    }
}
