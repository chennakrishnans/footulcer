package com.foot.project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.android.volley.Request;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONException;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;

public class doctor_settings extends AppCompatActivity {

    private TextView doctor_id, doctor_name, Age, Mobile_Number, gender;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_settings);

        // Initialize TextViews
        doctor_id = findViewById(R.id.textView46);
        doctor_name = findViewById(R.id.textView41);
        Age = findViewById(R.id.textView42);
        Mobile_Number = findViewById(R.id.textView44);
        gender = findViewById(R.id.textView43);

        // Fetch data from the server
        fetchDataFromServer();

        // ImageButton with ID imageButton14
        ImageButton imageButton14 = findViewById(R.id.imageButton14);

        // Set click listener for imageButton14
        imageButton14.setOnClickListener(view -> {
            // Create an Intent to navigate to doctor_homepage
            Intent intent = new Intent(doctor_settings.this, doctor_homepage.class);
            startActivity(intent);
        });
    }

    private void fetchDataFromServer() {
        String url = IPv4Connection.getBaseUrl() +"doctor_profile.php";

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, null,
                this::onResponse,
                error -> {
                    // Handle error
                });

        Volley.newRequestQueue(this).add(jsonObjectRequest);
    }

    private void onResponse(JSONObject response) {
        try {
            if (response.getBoolean("success")) {
                JSONObject data = response.getJSONObject("data");
                doctor_id.setText(data.getString("doctor_id"));
                doctor_name.setText(data.getString("doctor_name"));
                Age.setText(data.getString("Age"));
                Mobile_Number.setText(data.getString("Mobile Number"));
                gender.setText(data.getString("gender"));
            } else {
                // Handle other cases where the server response indicates an error
                // showError(response.getString("message"));
            }
        } catch (JSONException e) {
            e.printStackTrace();
            // Handle JSON parsing error, for example, display an error message to the user
            // showError("Error parsing JSON response");
        }
    }
}
