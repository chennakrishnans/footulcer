package com.foot.project;

import android.app.Activity;

public class upload_method_doctor extends Activity {
}
