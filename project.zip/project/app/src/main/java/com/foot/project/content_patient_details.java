package com.foot.project;

import android.app.Activity;

public class content_patient_details extends Activity {
}
