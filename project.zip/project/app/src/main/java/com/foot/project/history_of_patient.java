package com.foot.project;

import android.app.Activity;
import android.os.Bundle;

public class history_of_patient extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history_of_patient);

        // Your code for handling the history of the patient
    }
}
