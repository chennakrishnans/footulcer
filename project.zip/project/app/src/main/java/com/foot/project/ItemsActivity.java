package com.foot.project;

public class ItemsActivity {
    private String name;
    private String lastDateOfConsultation;
    private int patientId;

    public ItemsActivity(String patientId, String name, String lastDateOfConsultation) {
        this.patientId = Integer.parseInt(patientId);
        this.name = name;
        this.lastDateOfConsultation = lastDateOfConsultation;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastDateOfConsultation() {
        return lastDateOfConsultation;
    }

    public void setLastDateOfConsultation(String lastDateOfConsultation) {
        this.lastDateOfConsultation = lastDateOfConsultation;
    }

    public int getPatientId() {
        return patientId;
    }

    public void setPatientId(int patientId) {
        this.patientId = patientId;
    }
}
