package com.foot.project;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class patient_details extends Activity {

    private TextView nameTextView;
    private TextView ageTextView;
    private TextView genderTextView;
    private TextView mobileTextView;
    private TextView diagnosisTextView;
    private TextView dateOfOperationTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_details);

        View view5 = findViewById(R.id.view5);
        view5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(patient_details.this, history_of_patient.class);
                startActivity(intent);
            }
        });

        View view6 = findViewById(R.id.view6);
        view6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(patient_details.this, advise_for_patient.class);
                startActivity(intent);
            }
        });

        nameTextView = findViewById(R.id.textView71);
        ageTextView = findViewById(R.id.textView72);
        genderTextView = findViewById(R.id.textView73);
        mobileTextView = findViewById(R.id.textView76);
        diagnosisTextView = findViewById(R.id.textView74);
        dateOfOperationTextView = findViewById(R.id.textView75);

        // Get patient_id from intent extras
        Intent intent = getIntent();
        if (intent != null) {
            int patientId = intent.getIntExtra("patient_id", 0);
            String name = intent.getStringExtra("name");
            TextView nameTextView = findViewById(R.id.textView17);
            nameTextView.setText(name);


            // Fetch patient details from PHP script
            fetchPatientDetails(String.valueOf(patientId));
        }
    }

    private void fetchPatientDetails(String patientId) {
        String apiUrl = IPv4Connection.getBaseUrl() + "fetch_patient_details.php?patient_id=" + patientId;

        new AsyncTask<Void, Void, String>() {
            @Override
            protected String doInBackground(Void... voids) {
                try {
                    URL url = new URL(apiUrl);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("GET");

                    InputStream inputStream = conn.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }

                    reader.close();
                    inputStream.close();

                    return response.toString();
                } catch (IOException e) {
                    e.printStackTrace();
                    return null;
                }
            }

            @Override
            protected void onPostExecute(String result) {
                if (result != null) {
                    try {
                        JSONObject jsonResponse = new JSONObject(result);
                        boolean success = jsonResponse.getBoolean("success");
                        if (success) {
                            JSONArray dataArray = jsonResponse.getJSONArray("data");
                            JSONObject data = dataArray.getJSONObject(0);

                            String name = data.getString("Name");
                            String age = data.optString("Age", ""); // Use optString to handle missing keys
                            String gender = data.optString("Gender", "");
                            String mobileNumber = data.optString("Mobile_Number", "");
                            String diagnosis = data.optString("diagnosis", "");
                            String dateOfOperation = data.optString("Date_of_Operation", "");

                            // Display patient details in TextViews
                            nameTextView.setText(name);
                            ageTextView.setText(age);
                            genderTextView.setText(gender);
                            mobileTextView.setText(mobileNumber);
                            diagnosisTextView.setText(diagnosis);
                            dateOfOperationTextView.setText(dateOfOperation);
                        } else {
                            String message = jsonResponse.getString("message");
                            Log.e("patient_details", message);
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                } else {
                    Log.e("patient_details", "Failed to fetch data");
                }
            }
        }.execute();
    }
}
