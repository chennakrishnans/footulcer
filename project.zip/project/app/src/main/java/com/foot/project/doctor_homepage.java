package com.foot.project;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class doctor_homepage extends Activity {
    private MyAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_homepage);

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new MyAdapter(new ArrayList<>());
        recyclerView.setAdapter(adapter);

        // Fetch details from PHP script
        fetchDetails();
    }

    private void fetchDetails() {
        String apiUrl = IPv4Connection.getBaseUrl() + "fetch_patient_details.php";

        new AsyncTask<Void, Void, List<ItemsActivity>>() {
            @Override
            protected List<ItemsActivity> doInBackground(Void... voids) {
                return fetchDataFromServer(apiUrl);
            }

            @Override
            protected void onPostExecute(List<ItemsActivity> itemsList) {
                if (itemsList != null) {
                    adapter.setItems(itemsList);
                } else {
                    Log.e("doctor_homepage", "Failed to fetch data");
                }
            }
        }.execute();
    }

    private List<ItemsActivity> fetchDataFromServer(String apiUrl) {
        List<ItemsActivity> itemsList = new ArrayList<>();

        try {
            URL url = new URL(apiUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            InputStream inputStream = conn.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }

            // Check if the response is a JSON object
            JSONObject jsonResponse = new JSONObject(response.toString());
            if (jsonResponse.getBoolean("success")) {
                JSONArray jsonArray = jsonResponse.getJSONArray("data");
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    String patientId = jsonObject.getString("patient_id");
                    String name = jsonObject.getString("Name");
                    String dateOfOperation = jsonObject.getString("Date_of_Operation");

                    ItemsActivity item = new ItemsActivity(patientId, name, dateOfOperation);
                    itemsList.add(item);
                }
            } else {
                // Handle the case where the response indicates failure
                Log.e("doctor_homepage", jsonResponse.getString("message"));
            }

            reader.close();
            inputStream.close();
        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }

        return itemsList;
    }
}
