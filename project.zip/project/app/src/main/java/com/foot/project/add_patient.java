package com.foot.project;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class add_patient extends AppCompatActivity {

    private EditText patientIdEditText, nameEditText, ageEditText, genderEditText, mobileEditText,
            diagnosisEditText, dateOfOperationEditText;
    private Button addButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_patient);

        // Initialize EditText fields
        patientIdEditText = findViewById(R.id.patientIdEditText);
        nameEditText = findViewById(R.id.nameEditText);
        ageEditText = findViewById(R.id.ageEditText);
        genderEditText = findViewById(R.id.genderEditText);
        mobileEditText = findViewById(R.id.mobileNumberEditText);
        diagnosisEditText = findViewById(R.id.diagnosisEditText);
        dateOfOperationEditText = findViewById(R.id.dateOfOperationEditText);

        // Locate the Add button and set a click listener
        addButton = findViewById(R.id.addPatientButton);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Retrieve data from EditText fields
                String patientId = patientIdEditText.getText().toString();
                String name = nameEditText.getText().toString();
                String age = ageEditText.getText().toString();
                String gender = genderEditText.getText().toString();
                String mobile = mobileEditText.getText().toString();
                String diagnosis = diagnosisEditText.getText().toString();
                String dateOfOperation = dateOfOperationEditText.getText().toString();

                // Check if required fields are empty
                if (TextUtils.isEmpty(patientId) || TextUtils.isEmpty(name) || TextUtils.isEmpty(age)
                        || TextUtils.isEmpty(gender) || TextUtils.isEmpty(mobile) || TextUtils.isEmpty(diagnosis)
                        || TextUtils.isEmpty(dateOfOperation)) {
                    // Show a toast message indicating that all fields are required
                    Toast.makeText(add_patient.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                } else {
                    // Execute AsyncTask to send data to API
                    new AddPatientTask().execute(patientId, name, age, gender, mobile, diagnosis,
                            dateOfOperation);
                }
            }
        });
    }

    private class AddPatientTask extends AsyncTask<String, Void, Boolean> {
        @Override
        protected Boolean doInBackground(String... params) {
            String patientId = params[0];
            String name = params[1];
            String age = params[2];
            String gender = params[3];
            String mobile = params[4];
            String diagnosis = params[5];
            String dateOfOperation = params[6];
            String apiURL = IPv4Connection.getBaseUrl()+"addpatient.php"; // Update with your server address

            try {
                URL url = new URL(apiURL);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                conn.setDoOutput(true);

                // Create the POST data
                String postData = "patient_id=" + patientId + "&name=" + name + "&age=" + age +
                        "&gender=" + gender + "&Mobile_Number=" + mobile + "&diagnosis=" + diagnosis +
                        "&Date_of_operation=" + dateOfOperation;
                byte[] postDataBytes = postData.getBytes(StandardCharsets.UTF_8);

                // Write data to the server
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(postDataBytes);
                }

                // Get response from the server
                int responseCode = conn.getResponseCode();
                String responseMessage = conn.getResponseMessage();
                Log.d("AddPatientTask", "Response code: " + responseCode + ", Response message: " + responseMessage);

                return responseCode == HttpURLConnection.HTTP_OK;

            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
        }

        @Override
        protected void onPostExecute(Boolean success) {
            if (success) {
                // If the request is successful, display a toast message
                Toast.makeText(add_patient.this, "Patient added successfully", Toast.LENGTH_SHORT).show();
                // Proceed to another activity if needed
                Intent intent = new Intent(add_patient.this, doctor_homepage.class);
                startActivity(intent);
            } else {
                // If the request fails, display a toast message
                Toast.makeText(add_patient.this, "Failed to add patient", Toast.LENGTH_SHORT).show();
            }
        }
    }


}

