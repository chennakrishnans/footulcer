package com.foot.project;

import android.app.Activity;

public class settings_patients extends Activity {
}
