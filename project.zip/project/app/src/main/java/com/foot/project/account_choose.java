package com.foot.project;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class account_choose extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_choose);

        // Find the buttons by their IDs
        Button button3 = findViewById(R.id.button3);
        Button button2 = findViewById(R.id.button2); // Replace with the actual ID of the second button

        // Set click listeners on the buttons
        button3.setOnClickListener(view -> {
            // When button3 is clicked, start doctor_login activity
            Intent intent = new Intent(account_choose.this, doctor_login.class);
            startActivity(intent);
        });

        button2.setOnClickListener(view -> {
            // When button2 is clicked, start patient_login activity
            Intent intent = new Intent(account_choose.this, patient_login.class);
            startActivity(intent);
        });
    }
}
