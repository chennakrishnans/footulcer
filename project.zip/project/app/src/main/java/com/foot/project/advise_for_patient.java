package com.foot.project;

import android.app.Activity;
import android.os.Bundle;

public class advise_for_patient extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_advise_for_patient);

        // Your code for the advise for the patient activity
    }
}
