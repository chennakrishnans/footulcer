package com.foot.project;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class create_account extends AppCompatActivity {

    private EditText patientIdEditText, passwordEditText;
    private Button createButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        // Initialize EditText fields
        patientIdEditText = findViewById(R.id.editTextText3);
        passwordEditText = findViewById(R.id.editTextpass);

        // Locate the Create button and set a click listener
        createButton = findViewById(R.id.button8);
        createButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Retrieve patient ID and password from EditText fields
                String patientId = patientIdEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                // Check if patient ID and password are empty
                if (TextUtils.isEmpty(patientId) || TextUtils.isEmpty(password)) {
                    // Show a toast message indicating that both fields are required
                    Toast.makeText(create_account.this, "Please enter patient ID and password", Toast.LENGTH_SHORT).show();
                } else {
                    // If patient ID and password are not empty, proceed to create the account
                    // Execute AsyncTask to send data to API
                    new CreateUserTask().execute(patientId, password);
                }
            }
        });
    }

    private class CreateUserTask extends AsyncTask<String, Void, Boolean> {
        @Override
        protected Boolean doInBackground(String... params) {
            String patientId = params[0];
            String password = params[1];
            String apiURL = IPv4Connection.getBaseUrl()+"create_user.php"; // Replace with your API URL

            try {
                URL url = new URL(apiURL);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                conn.setDoOutput(true);

                // Create the POST data
                String postData = "patient_id=" + patientId + "&password=" + password;
                byte[] postDataBytes = postData.getBytes(StandardCharsets.UTF_8);

                // Write data to the server
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(postDataBytes);
                }

                // Get response from the server
                int responseCode = conn.getResponseCode();
                return responseCode == HttpURLConnection.HTTP_OK;

            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
        }

        @Override
        protected void onPostExecute(Boolean success) {
            if (success) {
                // If the request is successful, display a toast message
                Toast.makeText(create_account.this, "User created successfully", Toast.LENGTH_SHORT).show();
                // Proceed to another activity if needed
                Intent intent = new Intent(create_account.this, add_patient.class);
                startActivity(intent);
            } else {
                // If the request fails, display a toast message
                Toast.makeText(create_account.this, "Failed to create user", Toast.LENGTH_SHORT).show();
            }
        }
    }

}
