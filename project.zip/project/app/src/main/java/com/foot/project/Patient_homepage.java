package com.foot.project;

import android.annotation.SuppressLint;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.tabs.TabLayout;

public class Patient_homepage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_homepage);

        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) TabLayout tabLayout = findViewById(R.id.tabLayout);

        // Add tabs with icons
        TabLayout.Tab tab1 = tabLayout.newTab();
        tab1.setIcon(R.drawable.home); // Replace with your actual drawable resource
        tabLayout.addTab(tab1);

        TabLayout.Tab tab2 = tabLayout.newTab();
        tab2.setIcon(R.drawable.profile); // Replace with your actual drawable resource
        tabLayout.addTab(tab2);

        TabLayout.Tab tab3 = tabLayout.newTab();
        tab3.setIcon(R.drawable.uploads); // Replace with your actual drawable resource
        tabLayout.addTab(tab3);

        // Set up any additional configurations for the TabLayout as needed
    }
}
